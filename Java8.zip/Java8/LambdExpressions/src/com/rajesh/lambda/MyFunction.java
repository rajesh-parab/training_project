package com.rajesh.lambda;

public interface MyFunction {
 
  public void details(int i) throws Exception;
  
  
}
