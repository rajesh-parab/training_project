package com.rajesh.lambda.functional;

public interface Substract {

}
