package com.rajesh.lambda.functional;
@FunctionalInterface
public interface FunctionalInterfaceExample {
	 void test();
	 boolean equals(Object obj) ;

}
