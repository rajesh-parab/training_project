package com.rajesh.lambda.functional;

@FunctionalInterface
public interface Addition {

	int add(int x,int y);
	 
}
