package com.rajesh.lambda.functional;

public interface Compose {
  void apply();
}
