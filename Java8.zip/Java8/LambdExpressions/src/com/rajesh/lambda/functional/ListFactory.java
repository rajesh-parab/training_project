package com.rajesh.lambda.functional;

import java.util.ArrayList;

public interface ListFactory {
   <T> ArrayList<T> createList();
}
