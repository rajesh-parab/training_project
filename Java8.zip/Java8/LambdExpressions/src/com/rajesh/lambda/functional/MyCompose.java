package com.rajesh.lambda.functional;

@FunctionalInterface
public interface MyCompose extends Compose {
	 default void calculate(){   
		 // code
	 }
	 default void calculate1(){   
		 // codepu
	 }
	 static void print(){}
	  void apply();
}
