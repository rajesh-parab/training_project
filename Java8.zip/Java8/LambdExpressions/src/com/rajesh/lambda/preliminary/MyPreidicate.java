package com.rajesh.lambda.preliminary;

public interface MyPreidicate<T> {
	 boolean  test(T t);
}
