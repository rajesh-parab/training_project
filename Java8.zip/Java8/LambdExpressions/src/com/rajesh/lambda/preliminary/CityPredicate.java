package com.rajesh.lambda.preliminary;

public interface CityPredicate    {
    boolean  test(City city);
}
