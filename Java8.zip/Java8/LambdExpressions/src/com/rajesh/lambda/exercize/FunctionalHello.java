package com.rajesh.lambda.exercize;

public interface FunctionalHello {
  void apply();
}
