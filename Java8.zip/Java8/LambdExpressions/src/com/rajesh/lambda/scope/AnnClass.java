package com.rajesh.lambda.scope;

public interface AnnClass {
	
	int testMe(int i);

}
