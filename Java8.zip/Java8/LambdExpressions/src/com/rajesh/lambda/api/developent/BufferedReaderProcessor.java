package com.rajesh.lambda.api.developent;

import java.io.BufferedReader;
import java.io.IOException;

public interface BufferedReaderProcessor {
	
   String process(BufferedReader br) throws IOException;
}
