package com.rajesh.lambda;
 
public interface VarArgConsumer {

	String apply(String fmt, Object... args);
	 
}
