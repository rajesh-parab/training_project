package com.rajesh.lambda.method.reference;

public interface Person {
	
	default String getName(){
		return "Zensar";
	}
	
	

}
