package com.rajesh.lambda.method.reference;

public interface Printer {
	
	void print(String msg);
	
}
