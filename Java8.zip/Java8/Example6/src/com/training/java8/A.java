package com.training.java8;

public class A {
  public static void foo(){
	  System.out.println("A");
  }
}
