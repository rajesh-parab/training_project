package com.training.java8;

public class Student {
	
	private int age;
	
	public Student(int age){
		this.age = age;
	}

	public Integer getAge() {
		return Integer.valueOf(age);
	}
	

}
