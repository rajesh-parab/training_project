package com.training.java8;

public interface Command {
  void test();
}
