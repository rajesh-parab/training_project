package com.training.java8;

import java.util.function.Predicate;

public interface StringPredicate extends Predicate<String> {

}
