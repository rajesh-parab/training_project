package com.training.java8.feature;

public class C implements    A ,B{

	public static void main(String[] args) {
		   new C().sayHello();

	}

	 

}
