package com.training.java8.feature;

public interface A {
 default  void sayHello() {
	 System.out.println(" A hello");
 } 
}
