package com.training.java8.feature;

public interface D extends A {
	 
}
