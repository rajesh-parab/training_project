package com.rajesh.java8.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.annotation.NonNull;
import org.junit.Test;

public class Other {

	@Test
	public void period() {
		Double [] a = {1.2, 3.4, 5.9};
		List<@NonNull  Car> cars = new ArrayList<>();
		Arrays::<@NonNegative Integer>sort



	}

	 

}
