package com.rajesh.java8.training;

public class Car {

}
