package com.rajesh.lambda;

import java.util.HashSet;
import java.util.Set;

public class Tournament {

	 int tourId;
	 
	 String tourName;
	 
	 String tourType;
	 
	 Set<Member> members = new HashSet<>();

	 
	 public void addMember(Member m){
		 members.add(m);
	 }
	public int getTourId() {
		return tourId;
	}

	public void setTourId(int tourId) {
		this.tourId = tourId;
	}

	public String getTourName() {
		return tourName;
	}

	public void setTourName(String tourName) {
		this.tourName = tourName;
	}

	public String getTourType() {
		return tourType;
	}

	public void setTourType(String tourType) {
		this.tourType = tourType;
	}
	 
	 
}
