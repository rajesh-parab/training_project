package com.rajesh.lambda;

import org.junit.Test;

public class Exercize {
	
	@Test
	void test1(){
		
	}

}
