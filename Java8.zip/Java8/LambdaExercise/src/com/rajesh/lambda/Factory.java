package com.rajesh.lambda;

import java.util.ArrayList;
import java.util.List;

public class Factory {
	
	
	List<Tournament> getTournaments(){
		 List<Member>  members= getMembers();
		  
		  
		ArrayList<Tournament>  list = new ArrayList<>();
		
		
		Tournament e = new Tournament();
		e.setTourId(1);
		e.setTourName("swiming");
		e.setTourType("open");
		e.addMember(members.get(2));
		e.addMember(members.get(4));
		e.addMember(members.get(6));
		list.add(e );
		Tournament e1 = new Tournament();
		e1.setTourId(1);
		e1.setTourName("shooting");
		e1.setTourType("social");
		e1.addMember(members.get(1));
		e1.addMember(members.get(2));
		e1.addMember(members.get(4));
		e1.addMember(members.get(5));
		list.add(e1 );
		Tournament e2 = new Tournament();
		e2.setTourId(1);
		e2.setTourName("cycling");
		e2.setTourType("open");
		e1.addMember(members.get(3));
		e1.addMember(members.get(5));
		e2.addMember(members.get(6));
		list.add(e2 );
		
		
		
		return list;
	}

	List<Member> getMembers(){
		ArrayList<Member>  list = new ArrayList<>();
		
		Member m1=new Member();
		m1.setFirstName("Randy");
		m1.setLastName("Travis");
		m1.setMemberType("junior");
		m1.setPhone("23232");
		list.add(m1);
		Member m2=new Member();
		m2.setFirstName("Garth");
		m2.setLastName("Brooks");
		m2.setMemberType("junior");
		m2.setPhone("343343");
		list.add(m2);
		Member m3=new Member();
		m3.setFirstName("Rosane");
		m3.setLastName("Cash");
		m3.setMemberType("senior");
		m3.setPhone("4545");
		list.add(m3);
		Member m4=new Member();
		m4.setFirstName("Willie");
		m4.setLastName("Nelson");
		m4.setMemberType("senior");
		m4.setPhone("65656");
		list.add(m4);
		Member m5=new Member();
		m5.setFirstName("Don");
		m5.setLastName("Williams");
		m5.setMemberType("social");
		m5.setPhone("5454757");
		list.add(m5);
		Member m6=new Member();
		m6.setFirstName("Johnny");
		m6.setLastName("Cash");
		m6.setMemberType("senior");
		m6.setPhone("897865");
		list.add(m6);
		return list;
	}
}
